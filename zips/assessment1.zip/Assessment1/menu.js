document.getElementById("open").addEventListener("click",function(){
    document.getElementById("menu").style.left = "0px";
});

document.getElementById("close").addEventListener("click",function(){
    document.getElementById("menu").style.left = "-110px";
});